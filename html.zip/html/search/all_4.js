var searchData=
[
  ['inserttuple',['insertTuple',['../create_tuple_8c.html#a18138fefaefdbc8f31acd84a504d2b32',1,'insertTuple(char *subject, char *predicate, char *object):&#160;createTuple.c'],['../query_engine_8h.html#a18138fefaefdbc8f31acd84a504d2b32',1,'insertTuple(char *subject, char *predicate, char *object):&#160;createTuple.c']]]
];
