var searchData=
[
  ['obj',['OBJ',['../query_engine_8h.html#a7ac8b2d1e6f9bc687fb4686e3db0e5c2a3423cfdbb12fd9e0df94b2a7ae4dcea0',1,'queryEngine.h']]]
];
