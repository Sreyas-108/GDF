var indexSectionsWithContent =
{
  0: "bcdfimnopqrstu",
  1: "cdmnpqrsu",
  2: "dimnpqrsu",
  3: "t",
  4: "bt",
  5: "fopst",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros"
};

