var searchData=
[
  ['tri',['tri',['../query_engine_8h.html#a66e650b66170ed88b6f855023989392d',1,'queryEngine.h']]]
];
