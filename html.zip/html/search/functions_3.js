var searchData=
[
  ['notlegit',['notLegit',['../not_legit_8c.html#a526ffde1dd4298af259c4a62ab9d18b1',1,'notLegit(char *arr):&#160;notLegit.c'],['../query_engine_8h.html#a526ffde1dd4298af259c4a62ab9d18b1',1,'notLegit(char *arr):&#160;notLegit.c']]]
];
