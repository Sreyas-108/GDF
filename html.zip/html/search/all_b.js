var searchData=
[
  ['searchandinsert',['searchAndInsert',['../query_case2_8c.html#aa34e802a973472592915b87bc6464194',1,'searchAndInsert(FILE *fp, char key[], char **triples, int index, int flag, char flagCmp[]):&#160;queryCase2.c'],['../query_engine_8h.html#ab4d520d1f6983bb8f0d1fa1dcbcf39ce',1,'searchAndInsert(FILE *fp, char *key, char **triples, int index, int flag, char flagCmp[]):&#160;queryEngine.h']]],
  ['searchdriver_2ec',['searchDriver.c',['../search_driver_8c.html',1,'']]],
  ['solvesimpleselectquerycase1',['solveSimpleSelectQueryCase1',['../query_case1_8c.html#a6023ab79d26806c30186c0134c3d1cb7',1,'solveSimpleSelectQueryCase1(char *subject, char *predicate, char *object):&#160;queryCase1.c'],['../query_engine_8h.html#a6023ab79d26806c30186c0134c3d1cb7',1,'solveSimpleSelectQueryCase1(char *subject, char *predicate, char *object):&#160;queryCase1.c']]],
  ['solvesimpleselectquerycase2',['solveSimpleSelectQueryCase2',['../query_case2_8c.html#ae4f8bdce1f6ba8ddbcc93a65e152ea10',1,'solveSimpleSelectQueryCase2(char *subject, char *predicate, char *object):&#160;queryCase2.c'],['../query_engine_8h.html#ae4f8bdce1f6ba8ddbcc93a65e152ea10',1,'solveSimpleSelectQueryCase2(char *subject, char *predicate, char *object):&#160;queryCase2.c']]],
  ['solvesimpleselectquerycase3',['solveSimpleSelectQueryCase3',['../query_case3_8c.html#aae25ec83bedabf341aa01fa0726d1c67',1,'solveSimpleSelectQueryCase3(char *subject, char *predicate, char *object):&#160;queryCase3.c'],['../query_engine_8h.html#aae25ec83bedabf341aa01fa0726d1c67',1,'solveSimpleSelectQueryCase3(char *subject, char *predicate, char *object):&#160;queryCase3.c']]],
  ['sub',['SUB',['../query_engine_8h.html#a7ac8b2d1e6f9bc687fb4686e3db0e5c2a12b733d4941495e86811fe6ceeeff9da',1,'queryEngine.h']]]
];
