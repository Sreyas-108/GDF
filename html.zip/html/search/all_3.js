var searchData=
[
  ['false',['false',['../query_engine_8h.html#af6a258d8f3ee5206d682d799316314b1ae9de385ef6fe9bf3360d1038396b884c',1,'queryEngine.h']]]
];
