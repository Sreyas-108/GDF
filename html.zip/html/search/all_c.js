var searchData=
[
  ['tri',['tri',['../query_engine_8h.html#a7ac8b2d1e6f9bc687fb4686e3db0e5c2',1,'tri():&#160;queryEngine.h'],['../query_engine_8h.html#a66e650b66170ed88b6f855023989392d',1,'tri():&#160;queryEngine.h']]],
  ['true',['true',['../query_engine_8h.html#af6a258d8f3ee5206d682d799316314b1a08f175a5505a10b9ed657defeb050e4b',1,'queryEngine.h']]]
];
