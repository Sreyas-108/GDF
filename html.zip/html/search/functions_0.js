var searchData=
[
  ['deletetuple',['deleteTuple',['../delete_tuple_8c.html#a7a528eb63a63b2cb4e6e749759be99c8',1,'deleteTuple(char *subject, char *predicate, char *object):&#160;deleteTuple.c'],['../query_engine_8h.html#a7a528eb63a63b2cb4e6e749759be99c8',1,'deleteTuple(char *subject, char *predicate, char *object):&#160;deleteTuple.c']]]
];
