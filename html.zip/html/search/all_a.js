var searchData=
[
  ['removeline',['removeLine',['../query_engine_8h.html#a18c420050a4dfd2999fad1c2769fe741',1,'removeLine(char *filename, char *arr, int flag):&#160;removeLine.c'],['../remove_line_8c.html#a875153617a37b2ce98df7849318f09ae',1,'removeLine(char *filename, char *target, int flag):&#160;removeLine.c']]],
  ['removeline_2ec',['removeLine.c',['../remove_line_8c.html',1,'']]]
];
