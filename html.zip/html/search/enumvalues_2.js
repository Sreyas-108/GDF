var searchData=
[
  ['pred',['PRED',['../query_engine_8h.html#a7ac8b2d1e6f9bc687fb4686e3db0e5c2ae683fc24e76d5af0d7fdef96672e7a9f',1,'queryEngine.h']]]
];
