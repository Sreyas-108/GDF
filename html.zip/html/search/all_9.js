var searchData=
[
  ['query',['query',['../query_8c.html#ac1e803c52a74faed4ee06386fcf09ea5',1,'query(char subject[], char predicate[], char object[]):&#160;query.c'],['../query_engine_8h.html#a35958c7142fa39b8373b6896a5a90302',1,'query(char *subject, char *predicate, char *object):&#160;queryEngine.h']]],
  ['query_2ec',['query.c',['../query_8c.html',1,'']]],
  ['querycase1_2ec',['queryCase1.c',['../query_case1_8c.html',1,'']]],
  ['querycase2_2ec',['queryCase2.c',['../query_case2_8c.html',1,'']]],
  ['querycase3_2ec',['queryCase3.c',['../query_case3_8c.html',1,'']]],
  ['queryengine_2eh',['queryEngine.h',['../query_engine_8h.html',1,'']]]
];
