var searchData=
[
  ['parsequery',['parseQuery',['../parser_8c.html#aba39e13e4e6961c4ec8d0b2deb61712e',1,'parseQuery(char *query):&#160;parser.c'],['../query_engine_8h.html#aba39e13e4e6961c4ec8d0b2deb61712e',1,'parseQuery(char *query):&#160;parser.c']]],
  ['parser_2ec',['parser.c',['../parser_8c.html',1,'']]],
  ['pred',['PRED',['../query_engine_8h.html#a7ac8b2d1e6f9bc687fb4686e3db0e5c2ae683fc24e76d5af0d7fdef96672e7a9f',1,'queryEngine.h']]]
];
